<?php

namespace MatthiasMullie\Minify\Exceptions;

/**
 * @author Matthias Mullie <minify@mullie.eu>
 */
class IOException extends BasicException
{
}
