<?php

namespace MatthiasMullie\Minify\Exceptions;

use MatthiasMullie\Minify\Exception;

/**
 * @author Matthias Mullie <minify@mullie.eu>
 */
abstract class BasicException extends Exception
{
}
