---
name: Bug report
about: Standard SMF Bug report

---

#### Description
--Description Here--

### Steps to reproduce
1. 
2. 

### Environment (complete as necessary)
- Version/Git revision:
- Database Type:
- Database Version:
- PHP Version:


### Additional information/references